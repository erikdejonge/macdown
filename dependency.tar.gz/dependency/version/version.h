#ifndef VERSION_H
#define VERSION_H

static const char * const kMPApplicationShortVersion = "0.0.8";
static const char * const kMPApplicationBundleVersion = "8";

#endif
